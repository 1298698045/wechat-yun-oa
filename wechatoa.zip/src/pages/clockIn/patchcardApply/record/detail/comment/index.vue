<template>
    <div class="wrap">
        
    </div>
</template>
<script>
export default {
    data(){
        return {
            
        }
    }
}
</script>
<style lang="scss">
    
</style>