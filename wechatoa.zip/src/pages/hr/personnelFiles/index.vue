<template>
  <div class="wrap">
    <div class="header">
      <div class="avatar">
        测试
      </div>
      <div class="info">
        <p class="name">测试</p>
        <p class="department">技术部门</p>
        <p class="department">在百度工作了第三年</p>
      </div>
    </div>
    <div class="center">
      <div class="panel">
        <h3>基本信息</h3>
        <div class="content">
          <div class="row">
            <div class="info_wrap">
              <p class="label">姓名</p>
              <p class="name">测试</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">邮箱</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">部门</p>
              <p class="name">信息科室</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">职位</p>
              <p class="name">总监</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">手机号</p>
              <p class="name">+86-188****8888</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">工号</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">办公地点</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">入职时间</p>
              <p class="name">2020-01-01</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
        </div>
      </div>
      <div class="panel">
        <h3>工作信息</h3>
        <div class="content">
          <div class="row">
            <div class="info_wrap">
              <p class="label">员工类型</p>
              <p class="name">全职</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">员工状态</p>
              <p class="name">正式</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
        </div>
      </div>
      <div class="panel">
        <h3>个人信息</h3>
        <div class="content">
          <div class="row">
            <div class="info_wrap">
              <p class="label">身份证姓名</p>
              <p class="name">测试</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">证件号码</p>
              <p class="name">182479128********12 <span>显示</span></p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">出生日期</p>
              <p class="name">*****01-01 <span>显示</span></p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">年龄（系统计算）</p>
              <p class="name">** <span>显示</span></p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">性别</p>
              <p class="name">男</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">民族</p>
              <p class="name">汉族</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">身份证地址</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">证件有效期</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">婚姻状况</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">首次参加工作时间</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">工龄（系统计算）</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">户口类型</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">住址</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">政治面貌</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">个人社保账号</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
          <div class="row">
            <div class="info_wrap">
              <p class="label">个人公积金账号</p>
              <p class="name">未填写</p>
            </div>
            <div class="icon">
              <i-icon type="enter" color="#999999" size="20" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return {
      
    }
  }
}
</script>
<style lang="scss">
  .wrap{
    width: 100%;
    height: 100%;
    overflow: hidden;
    .header{
      padding: 33rpx 20rpx;
      background: #fff;
      display: flex;
      align-items: center;
      .avatar{
        width: 80rpx;
        height: 80rpx;
        line-height: 80rpx;
        font-size: 21rpx;
        color: #fff;
        border-radius: 50%;
        background: #3399ff;
        text-align: center;
      }
      .info{
        flex: 1;
        margin-left: 20rpx;
        .name{
          font-size: 34rpx;
          color: #333;
          font-weight: bold;
        }
        .department{
          font-size: 27rpx;
          color: #7d8081;
          margin-top: 6rpx;
        }
      }
    }
    .center{
      .panel{
        h3{
          font-size: 28rpx;
          color: #333333;
          padding: 30rpx ;
        }
        .content{
          background: #fff;
          .row{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20rpx 30rpx;
            border-bottom: 1rpx solid #e2e3e5;
            .info_wrap{
              .label{
                font-size: 25rpx;
                color: #7d8081;
              }
              .name{
                font-size: 35rpx;
                color: #333333;
                padding-top: 10rpx;
                span{
                  font-size: 22rpx;
                  color: #3399ff;
                }
              }
            }
            .icon{

            }
          }
        }
      }
    }
  }
</style>