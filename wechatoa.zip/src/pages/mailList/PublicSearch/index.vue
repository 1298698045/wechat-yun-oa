<template>
    <div class="wrap">
        <SearchCom :back="1" />
    </div>
</template>
<script>
import SearchCom from '@/components/mailList/searchCom';
export default {
    components:{
        SearchCom
    },
    data(){
        return {
            
        }
    }
}
</script>
<style lang="scss">
    
</style>