export declare const transition: (showDefaultValue: boolean) => any;
