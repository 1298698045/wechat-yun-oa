const nodes = ['1', '1-1', '1-1-2', '1-2-2']

export default {
    nodes
}